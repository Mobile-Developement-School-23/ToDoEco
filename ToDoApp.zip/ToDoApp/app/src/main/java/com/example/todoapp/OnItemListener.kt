package com.example.todoapp

interface OnItemListener {
    fun onItemClick(position: Int)
    fun inItemDelete(position: Int)
    fun inItemCheck(position: Int)
}