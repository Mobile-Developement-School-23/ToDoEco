package com.example.todoapp.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.NavController
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import com.example.todoapp.databinding.FragmentHomeBinding
import com.example.todoapp.OnItemListener
import com.example.todoapp.ui.adapters.ToDoAdapter
import com.example.todoapp.ui.handlers.SwipeGesture
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar

class HomeFragment : Fragment(), OnItemListener {

    private var _binding: FragmentHomeBinding? = null

    private val binding get() = _binding!!

    private val homeViewModel: HomeAndAddViewModel by activityViewModels()

    private lateinit var adapter: ToDoAdapter

    private lateinit var recyclerView: RecyclerView

    private lateinit var navController: NavController

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root


        recyclerViewInit()
        floatButtonInit()

        return root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        homeViewModel.toDoList.observe(viewLifecycleOwner) {
            toDoList -> adapter.notifyDataSetChanged()
        }
    }

    fun floatButtonInit() {
        _binding!!.editAddFragmentButton.setOnClickListener {
         findNavController().navigate(R.id.nav_gallery)
            homeViewModel.setStateFlag(2)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun recyclerViewInit() {
        recyclerView = _binding!!.taskRecycler

        adapter = ToDoAdapter(requireContext(), homeViewModel.toDoList.value!!, this)


        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        swipeToGesture(recyclerView)

    }

    override fun onItemClick(position: Int) {
        val clickedItem = adapter.getItem(position)
        homeViewModel.setFilledModel(clickedItem)
        findNavController().navigate(R.id.nav_gallery)
        homeViewModel.setStateFlag(1)
    }

    override fun inItemCheck(position: Int) {
       // сделать реализацию отметки о том, что дело сделано
    }

    override fun inItemDelete(position: Int) {
        // сделать реализацию удаления
    }

    private fun swipeToGesture(itemRv: RecyclerView?) {
        val swipeGesture=object : SwipeGesture(requireContext()){
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position=viewHolder.adapterPosition
                var actionBtnTapped = false
                try {
                    when(direction){
                        ItemTouchHelper.LEFT->{



                            // removing

                            val snackBar = Snackbar.make(
                               this@HomeFragment.recyclerView, "Item Deleted", Snackbar.LENGTH_LONG
                            ).addCallback(object : BaseTransientBottomBar.BaseCallback<Snackbar>() {
                                override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                                    super.onDismissed(transientBottomBar, event)
                                }
                                override fun onShown(transientBottomBar: Snackbar?) {
                                    transientBottomBar?.setAction("UNDO") {
                                        // logic
                                        actionBtnTapped = true
                                    }
                                    super.onShown(transientBottomBar)
                                }
                            }).apply {
                                animationMode = Snackbar.ANIMATION_MODE_FADE
                            }
                            snackBar.setActionTextColor(
                                ContextCompat.getColor(
                                    requireContext(),
                                    R.color.red
                                )
                            )
                            snackBar.show()
                        }

                        ItemTouchHelper.RIGHT->{

                            // info display

                            val snackBar = Snackbar.make(
                                this@HomeFragment.recyclerView, "Item Info", Snackbar.LENGTH_LONG
                            ).addCallback(object : BaseTransientBottomBar.BaseCallback<Snackbar>() {
                                override fun onDismissed(transientBottomBar: Snackbar?, event: Int) {
                                    super.onDismissed(transientBottomBar, event)
                                }
                                override fun onShown(transientBottomBar: Snackbar?) {
                                    transientBottomBar?.setAction("UNDO") {

                                        actionBtnTapped = true
                                    }
                                    super.onShown(transientBottomBar)
                                }
                            }).apply {
                                animationMode = Snackbar.ANIMATION_MODE_FADE
                            }
                            snackBar.setActionTextColor(
                                ContextCompat.getColor(
                                    requireContext(),
                                    R.color.red
                                )
                            )
                            snackBar.show()
                        }
                    }
                }
                catch (e:Exception){

                    Toast.makeText(requireContext(), e.message, Toast.LENGTH_SHORT).show()

                }
            }
        }
        val touchHelper=ItemTouchHelper(swipeGesture)
        touchHelper.attachToRecyclerView(itemRv)

    }}