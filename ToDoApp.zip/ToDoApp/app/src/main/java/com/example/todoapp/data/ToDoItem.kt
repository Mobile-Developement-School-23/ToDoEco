package com.example.todoapp.data

import java.util.Date

data class ToDoItem(
    val id: String,
    val text: String,
    val importance: Importance,
    val deadline: Date? = null,
    val isDone: Boolean,
    val creationDate: Date,
    val modificationDate: Date? = null
) {
    enum class Importance {
        LOW, NORMAL, URGENT
    }
}
