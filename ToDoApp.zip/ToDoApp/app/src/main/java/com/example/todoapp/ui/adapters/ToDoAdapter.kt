package com.example.todoapp.ui.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.data.ToDoItem
import com.example.todoapp.R
import com.example.todoapp.OnItemListener
import java.text.SimpleDateFormat
import java.util.*

class ToDoAdapter(private val context: Context, private val todoList: List<ToDoItem>, private  val listener: OnItemListener) :
    RecyclerView.Adapter<ToDoAdapter.ViewHolder>() {

    fun deleteItem(position: Int) {

        listener.inItemDelete(position)

    }

    fun checkItem(position: Int) {

        listener.inItemCheck(position)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.to_do_layout, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val todoItem = todoList[position]
        holder.itemView.setOnClickListener {
            listener.onItemClick(position)
        }
        holder.bind(todoItem)
    }

    override fun getItemCount(): Int {
        return todoList.size
    }

    fun getItem(position: Int) : ToDoItem {
        return todoList[position]
    }

    inner class ViewHolder(itemView: View) :
        RecyclerView.ViewHolder(itemView) {

        private val todoText: TextView = itemView.findViewById(R.id.task)
        private val deadline: TextView = itemView.findViewById(R.id.deadline)
        private val importanceIndicator: ImageView = itemView.findViewById(R.id.importance)
        private val completionStatus: CheckBox = itemView.findViewById(R.id.doOrNo)

        fun bind(todoItem: ToDoItem) {

            todoText.text = todoItem.text

            val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())

            if (todoItem.deadline != null) {
                deadline.text = dateFormat.format(todoItem.deadline)
            }

            val importanceIcon = when (todoItem.importance) {
                ToDoItem.Importance.LOW -> R.drawable.slow
                ToDoItem.Importance.NORMAL -> R.drawable.normally
                ToDoItem.Importance.URGENT -> R.drawable.urgently
            }

            importanceIndicator.setImageResource(importanceIcon)

            completionStatus.isChecked = todoItem.isDone
        }
    }
}