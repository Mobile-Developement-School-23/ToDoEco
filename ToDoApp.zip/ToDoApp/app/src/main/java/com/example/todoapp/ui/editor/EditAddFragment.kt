package com.example.todoapp.ui.editor

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import com.example.todoapp.data.ToDoItem
import com.example.todoapp.databinding.FragmentEditBinding
import com.example.todoapp.ui.home.HomeAndAddViewModel
import java.util.Calendar
import java.util.Date


class EditAddFragment : Fragment() {

    private var _binding: FragmentEditBinding? = null

    private val binding get() = _binding!!

    private val homeAndAddViewModel: HomeAndAddViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentEditBinding.inflate(inflater, container, false)

        val root: View = binding.root
        init()
        return root

    }


    override fun onDestroyView() {

        super.onDestroyView()
        _binding = null

    }

    private fun init() {

        // в зависимости от того, хочет ли пользователь установить дедлайн -
        // показать и скрыть календарь

        binding.showCalendar.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.myDeadlineDatePicker.visibility = View.VISIBLE
            } else {
                binding.myDeadlineDatePicker.visibility = View.GONE
            }
        }

        // заполнение данных по объекту из ViewModel

        val text = homeAndAddViewModel.getFilledModel().text

        binding.descriptionInput.setText(text)

        val importance = homeAndAddViewModel.getFilledModel().importance
        val deadline : Date? = homeAndAddViewModel.getFilledModel().deadline


        when (importance) {
            ToDoItem.Importance.LOW -> _binding!!.toggleButtonImportance
                .check(_binding!!.slowButton.id)
            ToDoItem.Importance.NORMAL -> _binding!!.toggleButtonImportance
                .check(_binding!!.normalButton.id)
            ToDoItem.Importance.URGENT -> _binding!!.toggleButtonImportance
                .check(_binding!!.urgentlyButton.id)
        }

        if (deadline != null) {

            binding.showCalendar.isChecked = true
            binding.myDeadlineDatePicker.visibility = View.VISIBLE

            val calendar = Calendar.getInstance()
            calendar.time = deadline

            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)
            binding.myDeadlineDatePicker.updateDate(year, month, day)

        } else {

            binding.showCalendar.isChecked = false
            binding.myDeadlineDatePicker.visibility = View.GONE

        }


        // обработка нажатия на "Отмену"

        binding.cancelButton.setOnClickListener {

           showCancelWarningDialog()

        }

        // обработка нажатия на "Сохранить"

        binding.saveButton.setOnClickListener {

            fillModel()

            if (homeAndAddViewModel.getStateFlag() == 1) {

                showSaveWarningDialog()

            } else if (homeAndAddViewModel.getStateFlag() == 2) {

                showNewSaveWarningDialog()

            }

        }

        // обработка нажатия на "Удалить"

        binding.removeButton.setOnClickListener {

            if (homeAndAddViewModel.getStateFlag() == 1) {

                showRemoveWarningDialog()

            } else if (homeAndAddViewModel.getStateFlag() == 2) {

                showCancelWarningDialog()

            }

        }

    }

    private fun showCancelWarningDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Cancel")
            .setMessage("Are you sure you want to close the editor?")
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton("OK") { dialog, _ ->
                homeAndAddViewModel.removeFilledModel()
                requireActivity().supportFragmentManager.popBackStack()
            }
            .setNegativeButton("Cancel") { dialog, _ ->

                dialog.dismiss()

            }
            .show()
    }

    private fun showSaveWarningDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Save")
            .setMessage("Are you sure you want to save the task?")
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton("OK") { dialog, _ ->
                homeAndAddViewModel.saveDataToRepo()
                homeAndAddViewModel.removeFilledModel()
                requireActivity().supportFragmentManager.popBackStack()
            }
            .setNegativeButton("Cancel") { dialog, _ ->

                dialog.dismiss()
            }
            .show()
    }

    private fun showRemoveWarningDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Warning")
            .setMessage("This is a warning message.")
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton("OK") { dialog, _ ->
                homeAndAddViewModel.removeDataFromRepo()
                homeAndAddViewModel.removeFilledModel()
                requireActivity().supportFragmentManager.popBackStack()
            }
            .setNegativeButton("Cancel") { dialog, _ ->

                dialog.dismiss()
            }
            .show()
    }

    private fun showNewSaveWarningDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Save")
            .setMessage("Are you sure you want to save the new task?")
            .setIcon(android.R.drawable.ic_dialog_alert)
            .setPositiveButton("OK") { dialog, _ ->
                homeAndAddViewModel.addDataToRepo()
                homeAndAddViewModel.nextId()
                homeAndAddViewModel.removeFilledModel()
                requireActivity().supportFragmentManager.popBackStack()
            }
            .setNegativeButton("Cancel") { dialog, _ ->

                dialog.dismiss()
            }
            .show()
    }

    private fun fillModel() {

        // сбор данных с элементов Фрагмента для заполнения Модели

    }

    }
